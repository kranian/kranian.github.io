/*****************************************************************
 ** @author   STF 470
 ** @version  0.0.1
 ** @purpose  1:8.2.3.1, Verify that identifiers of parameter types are not imported together with external functions
 ** @verdict  pass reject
 *****************************************************************/

#include "NegSem_160104_invoking_functions_from_specific_places_120.hh"

namespace NegSem__160104__invoking__functions__from__specific__places__120
{

	BOOLEAN xf__NegSem__160104__invoking__functions__from__specific__places__120()
    {
		return true;
	}
}
