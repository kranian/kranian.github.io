/*****************************************************************
 ** @author   STF 470
 ** @version  0.0.1
 ** @purpose  1:8.2.3.1, Verify that identifiers of parameter types are not imported together with external functions
 ** @verdict  pass reject
 *****************************************************************/

#include "NegSem_2002_TheAltStatement_050.hh"

namespace NegSem__2002__TheAltStatement__050
{

	BOOLEAN xf__NegSem__2002__TheAltStatement__050()
    {
		return true;
	}
}
