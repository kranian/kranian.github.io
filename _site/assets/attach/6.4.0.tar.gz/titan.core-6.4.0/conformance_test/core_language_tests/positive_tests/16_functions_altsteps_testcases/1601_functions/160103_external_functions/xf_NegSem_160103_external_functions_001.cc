/*****************************************************************
 ** @author   STF 470
 ** @version  0.0.1
 ** @purpose  1:8.2.3.1, Verify that identifiers of parameter types are not imported together with external functions
 ** @verdict  pass reject
 *****************************************************************/

#include "NegSem_160103_external_functions_001.hh"

namespace NegSem__160103__external__functions__001
{

	INTEGER_template xf__NegSem__160103__external__functions__001()
    {
		return 1;
	}
}
