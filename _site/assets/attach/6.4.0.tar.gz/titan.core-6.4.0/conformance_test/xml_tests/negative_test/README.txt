// README to negative xml conformance tests

How to run:
	./SAtester_XML.pl neg_xml_tests.script

IMPORTANT:
UsefulTtcn3Types.txt and XSD.txt are needed for running
xsd_tmp_keyword and usefultypes_tmp_keyword are changed for these files during running

neg_tc_sample is a sample format for tests in neg_xml_tests.script
 
